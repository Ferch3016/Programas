import re
from collections import defaultdict

# Definimos la función para contar las secuencias por identificador
def contar_secuencias_por_identificador(ruta_archivo):
    # Implementar un diccionario para almacenar los conteos
    conteos_secuencias = defaultdict(int)
    
    # Abrir el archivo para que lo lea línea por línea
    with open(ruta_archivo, 'r') as archivo:
        for linea in archivo:
            # Utiliza expresiones regulares para encontrar identificadores
            coincidencia = re.match(r'>(PZ\d+)', linea)
            if coincidencia:
                # Incrementa el conteo para el identificador encontrado
                conteos_secuencias[coincidencia.group(1)] += 1
    
    # Devuelve el diccionario con los conteos
    return conteos_secuencias

# Llama a la función y almacena el resultado
conteos_identificadores = contar_secuencias_por_identificador('pz_cDNAs.fasta')

# Imprime los resultados
for identificador, conteo in conteos_identificadores.items():
    print(f"{identificador}\t{conteo}")
